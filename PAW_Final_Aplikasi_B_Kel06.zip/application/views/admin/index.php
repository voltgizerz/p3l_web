<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?> - Admin AREA</h1>
    <h2 class="h3 mb-4 text-gray-800">WELCOME BACK to RichzAuto</h2>
    <img src=" <?= base_url('assets/img/sian1.jpg'); ?>" width="100%" height="400">

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->