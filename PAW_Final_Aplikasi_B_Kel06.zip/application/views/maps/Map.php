<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title>Welcome to Google Map</title>
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>
    <?php echo $map['js']; ?>
</head>

<body>
    <?php echo $map['html']; ?>
</body>

</html>